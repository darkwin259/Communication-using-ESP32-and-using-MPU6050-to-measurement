All audio samples by Pitx (http://www.freesound.org/usersViewSingle.php?id=40665),
licensed under Creative Commons Sampling Plus 1.0

http://creativecommons.org/licenses/sampling+/1.0/

