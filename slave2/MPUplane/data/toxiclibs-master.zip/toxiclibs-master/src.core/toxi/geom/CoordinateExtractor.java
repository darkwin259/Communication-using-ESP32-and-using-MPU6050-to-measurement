package toxi.geom;

public interface CoordinateExtractor<T> {

    public float coordinate(T obj);
}
