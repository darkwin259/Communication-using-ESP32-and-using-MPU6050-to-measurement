package toxi.volume;

public interface BrushMode {

    public float apply(float orig, float brush);
}
