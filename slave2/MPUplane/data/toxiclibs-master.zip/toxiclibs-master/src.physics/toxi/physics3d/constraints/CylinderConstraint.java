/*
 *   __               .__       .__  ._____.           
 * _/  |_  _______  __|__| ____ |  | |__\_ |__   ______
 * \   __\/  _ \  \/  /  |/ ___\|  | |  || __ \ /  ___/
 *  |  | (  <_> >    <|  \  \___|  |_|  || \_\ \\___ \ 
 *  |__|  \____/__/\_ \__|\___  >____/__||___  /____  >
 *                   \/       \/             \/     \/ 
 *
 * Copyright (c) 2006-2011 Karsten Schmidt
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * http://creativecommons.org/licenses/LGPL/2.1/
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 */

package toxi.physics3d.constraints;

import toxi.geom.AxisAlignedCylinder;
import toxi.geom.Vec3D;
import toxi.physics3d.VerletParticle3D;

public class CylinderConstraint implements ParticleConstraint3D {

    protected AxisAlignedCylinder cylinder;
    protected Vec3D centroid = new Vec3D();
    protected Vec3D.Axis axis;

    public CylinderConstraint(AxisAlignedCylinder cylinder) {
        setCylinder(cylinder);
    }

    public void apply(VerletParticle3D p) {
        if (cylinder.containsPoint(p)) {
            centroid.setComponent(axis, p.getComponent(axis));
            p.set(centroid.add(p.sub(centroid)
                    .normalizeTo(cylinder.getRadius())));
        }
    }

    /**
     * @return the cylinder
     */
    public AxisAlignedCylinder getCylinder() {
        return cylinder;
    }

    /**
     * @param cylinder
     *            the cylinder to set
     */
    public void setCylinder(AxisAlignedCylinder cylinder) {
        this.cylinder = cylinder;
        centroid.set(cylinder.getPosition());
        axis = cylinder.getMajorAxis();
    }
}
