package com.toxi.net;

public enum ServerState {
    WAITING_FOR_CLIENTS, SYNCHING
}
